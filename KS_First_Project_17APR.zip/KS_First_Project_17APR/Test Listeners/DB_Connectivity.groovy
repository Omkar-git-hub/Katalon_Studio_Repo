import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.Statement

import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

class DB_Connectivity {

    static Connection conn = null

    @BeforeTestCase
    def beforeTestCase(TestCaseContext testCaseContext) {
        Class.forName("com.mysql.cj.jdbc.Driver")
        String dbUrl = "jdbc:mysql://localhost:3306/katalon"
        String username = "root"
        String password = "your_password_here"

        conn = DriverManager.getConnection(dbUrl, username, password)

        // Fetch one row from DB and assign to GlobalVariables
        String query = "SELECT * FROM DB01 LIMIT 1"
        Statement stmt = conn.createStatement()
        ResultSet rs = stmt.executeQuery(query)

        if (rs.next()) {
            GlobalVariable.NAME = rs.getString("Name")
            GlobalVariable.EMAIL = rs.getString("Email")
            GlobalVariable.MSG = "Your message here"  // Or get from DB if exists
            GlobalVariable.NUM = "1234567890"          // Or get from DB if exists
            GlobalVariable.TECH = rs.getString("Course")
        }

        rs.close()
        stmt.close()
    }

    @AfterTestCase
    def afterTestCase(TestCaseContext testCaseContext) {
        if (conn != null && !conn.isClosed()) {
            conn.close()
        }
        WebUI.deleteAllCookies()
        WebUI.closeBrowser()
    }
}
