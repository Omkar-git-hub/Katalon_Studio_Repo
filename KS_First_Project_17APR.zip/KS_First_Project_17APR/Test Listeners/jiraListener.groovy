import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.context.TestCaseContext
import groovy.json.JsonOutput
import java.net.HttpURLConnection
import java.net.URL

class jiraListener {

    @AfterTestCase
    def afterTestCase(TestCaseContext testCaseContext) {

        if (testCaseContext.getTestCaseStatus() == 'PASSED') {

            // === Jira Account Info ===
            def jiraDomain = "learn-jira-bro.atlassian.net"
            def projectKey = "KIPD"
            def email = "21091032_aids@adcet.ac.in"
            def apiToken = "ATATT3xFfGF0s66POneZgYmLRXJSyTwgVH5v3ATUyzCgBU1fEirZ70ry6YN0Jj2sOeUTzyjVBcj29FxghrDM0i5atCmwfl9obO3VKtGO582wwZ8GOgXwGEwccpNd1MyNThR231CGapUXrnENFFPFRRF9NthN9IvTRmbgQ9g_vpdqNu02c9Rmdng=DD1305B0"

            // === Encode Auth ===
            def auth = email + ":" + apiToken
            def encodedAuth = "Basic " + auth.bytes.encodeBase64().toString()

            // === Issue Data ===
            def issueData = [
                fields: [
                    project: [key: projectKey],
                    summary: "Auto-Bug: " + testCaseContext.getTestCaseId(),
                    description: "Test Case Failed\n\nID: " + testCaseContext.getTestCaseId() +
                                 "\nStatus: " + testCaseContext.getTestCaseStatus(),
                    issuetype: [name: "Task"]
                ]
            ]

            // === Send to Jira ===
            def url = new URL("https://${jiraDomain}/rest/api/2/issue")
            def connection = (HttpURLConnection) url.openConnection()

            connection.with {
                doOutput = true
                requestMethod = 'POST'
                setRequestProperty('Authorization', encodedAuth)
                setRequestProperty('Content-Type', 'application/json')
                outputStream.write(JsonOutput.toJson(issueData).getBytes("UTF-8"))
            }

            // === Response ===
            println "Jira response code: " + connection.responseCode
            println connection.inputStream.text
        }
    }
}
