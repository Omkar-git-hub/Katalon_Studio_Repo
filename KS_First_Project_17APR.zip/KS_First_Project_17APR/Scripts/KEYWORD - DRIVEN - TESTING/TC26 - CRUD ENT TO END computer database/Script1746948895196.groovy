import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import groovy.transform.PackageScope as PackageScope
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.maximizeWindow()

WebUI.navigateToMaskedUrl('https://computer-database.gatling.io/computers')

boolean Verify_CB = WebUI.verifyTextPresent('Computer database', false)

if (Verify_CB == true) {
    println('Computer database is Present')
} else {
    println('Computer database is Not Present')
}

WebUI.click(findTestObject('Computers_database_OR/a_Add a new computer'))

WebUI.sendKeys(findTestObject('Computers_database_OR/input_Computer name_name'), 'ASUS Strik')

WebUI.sendKeys(findTestObject('Computers_database_OR/input_Introduced_introduced'), '2002-05-09')

WebUI.sendKeys(findTestObject('Computers_database_OR/input_Discontinued_discontinued'), '2020-05-09')

WebUI.selectOptionByLabel(findTestObject('Computers_database_OR/select_-- Choose a company --Apple Inc.Thinking MachinesRCANetronicsTandy CorporationCommodore InternationalMOS TechnologyMicro Instrumentation and Telemetry SystemsIMS Associates, Inc.Digital Equipment CorporationLincol'), 
    'IBM', false)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Computers_database_OR/Create_Comp_btn'))

boolean Verify_Created = WebUI.verifyTextPresent('Done ! Computer ASUS Strik has been created', false)

if (Verify_Created == true) {
    println('Done ! Computer ASUS Strik has been created')
} else {
    println('Not Done ! Computer ASUS Strik has been created')
}

WebUI.click(findTestObject('Computers_database_OR/a_ACE'))

WebUI.clearText(findTestObject('Computers_database_OR/input_Computer name_name'))

WebUI.setText(findTestObject('Computers_database_OR/input_Computer name_name'), 'Envy')

WebUI.setText(findTestObject('Computers_database_OR/input_Introduced_introduced'), '2020-12-12')

WebUI.setText(findTestObject('Computers_database_OR/input_Discontinued_discontinued'), '2025-10-10')

WebUI.selectOptionByIndex(findTestObject('Computers_database_OR/select_-- Choose a company --Apple Inc.Thinking MachinesRCANetronicsTandy CorporationCommodore InternationalMOS TechnologyMicro Instrumentation and Telemetry SystemsIMS Associates, Inc.Digital Equipment CorporationLincol'), 
    15)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Computers_database_OR/Save_this_Comp_Update'), FailureHandling.STOP_ON_FAILURE)

boolean Verify_Envy_P = WebUI.verifyTextPresent('Done ! Computer Envy has been updated', false)

if (Verify_Envy_P == true) {
    println('Done ! Computer Envy has been Renamed')
}

WebUI.click(findTestObject('Computers_database_OR/a_ACE'), FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('Computers_database_OR/input_Computer name_name'), 'Asus RogStrick')

WebUI.setText(findTestObject('Computers_database_OR/input_Introduced_introduced'), '2020-11-11')

WebUI.setText(findTestObject('Computers_database_OR/input_Discontinued_discontinued'), '2025-11-11')

WebUI.selectOptionByIndex(findTestObject('Computers_database_OR/select_-- Choose a company --Apple Inc.Thinking MachinesRCANetronicsTandy CorporationCommodore InternationalMOS TechnologyMicro Instrumentation and Telemetry SystemsIMS Associates, Inc.Digital Equipment CorporationLincol'), 
    10)

WebUI.takeScreenshot()

WebUI.click(findTestObject('Computers_database_OR/Save_this_Comp_Update'))

boolean Verify_ACE_P = WebUI.verifyTextPresent('Done ! Computer Asus RogStrick has been updated', false)

if (Verify_ACE_P == true) {
    println('Done ! Computer ACE has been updated')
} else {
    println('Not Done ! Computer ACE has been updated')
}

WebUI.takeScreenshot()

WebUI.click(findTestObject('Computers_database_OR/a_ACE'))

WebUI.click(findTestObject('Computers_database_OR/Delete_Comp_btn'))

boolean Delete_Comp_ACE = WebUI.verifyTextPresent('Done ! Computer ACE has been deleted', false)

if (Delete_Comp_ACE == true) {
    println('Done ! Computer ACE has been deleted')
} else {
    println('Not Done ! Computer ACE has been deleted')
}

String path = WebUI.takeScreenshot()

println('Path is : ' + path)

WebUI.deleteAllCookies()

WebUI.closeBrowser()

