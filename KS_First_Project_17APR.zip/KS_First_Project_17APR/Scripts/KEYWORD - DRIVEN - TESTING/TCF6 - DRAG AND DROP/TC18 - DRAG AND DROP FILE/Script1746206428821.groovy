import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.maximizeWindow()

WebUI.navigateToUrl('http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html')

WebUI.scrollToPosition(0, 200)

def Scr1  = WebUI.takeScreenshot()
println("Path of 1st Screenshot : " + Scr1)

WebUI.delay(2)

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/1_oslo_norway'), findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Norway_1'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/2_stockholm_sweden'), findTestObject(
        'DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Sweden_2'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/3_rome_italy'), findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Italy_3'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/4_Washingtone_us_'), findTestObject(
        'DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Us_6'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/5_Seoul_SK'), findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Sk_7'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/6_Madrid_spain'), findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Spain_4'))

WebUI.dragAndDropToObject(findTestObject('DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/7_Copenhagen_denmark'), findTestObject(
        'DRAG_AND_DROP_OR/dhtmlgoodies.com dragNdrop/Denmark_5'))

def Sc2 = WebUI.takeScreenshot()
println("Path of 2nd Screenshot : " + Sc2)

WebUI.deleteAllCookies()

WebUI.closeBrowser()



