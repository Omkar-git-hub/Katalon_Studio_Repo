import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

// Step 17: Click on 'ACE'
WebUI.openBrowser('https://computer-database.gatling.io/computers')

WebUI.maximizeWindow()

WebUI.click(findTestObject('Computers_database_OR/a_ACE'))

// Step 18: Clear existing computer name
WebUI.clearText(findTestObject('Computers_database_OR/input_Computer name_name'))

// Step 19: Set new name "Envy"
WebUI.setText(findTestObject('Computers_database_OR/input_Computer name_name'), 'Envy')

// Step 20: Set Introduced date
WebUI.setText(findTestObject('Computers_database_OR/input_Introduced_introduced'), '2020-12-12')

// Step 21: Set Discontinued date
WebUI.setText(findTestObject('Computers_database_OR/input_Discontinued_discontinued'), '2025-10-10')

// Step 22: Select company by index (e.g., 15)
WebUI.selectOptionByIndex(findTestObject('Computers_database_OR/select_-- Choose a company --Apple Inc.Thinking MachinesRCANetronicsTandy CorporationCommodore InternationalMOS TechnologyMicro Instrumentation and Telemetry SystemsIMS Associates, Inc.Digital Equipment CorporationLincol'), 
    15)

// Step 23: Take a screenshot after updating
WebUI.takeScreenshot()

// Step 24: Click Save button
WebUI.click(findTestObject('Computers_database_OR/Save_this_Comp_Update'))

// Step 25: Verify success message for "Envy"
boolean Verify_Envy_P = WebUI.verifyTextPresent('Done ! Computer Envy has been updated', false)

// Step 26: Conditional print
if (Verify_Envy_P == true) {
    println('Done ! Computer Envy has been Renamed')
}

