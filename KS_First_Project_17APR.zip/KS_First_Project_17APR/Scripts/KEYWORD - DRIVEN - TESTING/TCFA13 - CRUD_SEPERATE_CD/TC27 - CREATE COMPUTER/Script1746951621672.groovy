import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

// Step 1: Open browser
WebUI.openBrowser('')

// Step 2: Maximize browser window
WebUI.maximizeWindow()

// Step 3: Navigate to computer database website
WebUI.navigateToUrl('https://computer-database.gatling.io/computers')

// Step 4: Verify that the heading "Computer database" is present
boolean isTextPresent = WebUI.verifyTextPresent('Computer database', false)

if (isTextPresent) {
    println('Computer database is Present')
} else {
    println('Computer database is Not Present')
}

// Step 5: Click "Add a new computer"
WebUI.click(findTestObject('Computers_database_OR/a_Add a new computer'))

// Step 6: Enter computer name
WebUI.sendKeys(findTestObject('Computers_database_OR/input_Computer name_name'), 'ASUS Strik')

// Step 7: Enter introduced date
WebUI.sendKeys(findTestObject('Computers_database_OR/input_Introduced_introduced'), '2002-05-09')

// Step 8: Enter discontinued date
WebUI.sendKeys(findTestObject('Computers_database_OR/input_Discontinued_discontinued'), '2020-05-09')

// Step 9: Select company by label
WebUI.selectOptionByLabel(findTestObject('Computers_database_OR/select_-- Choose a company --Apple Inc.Thinking MachinesRCANetronicsTandy CorporationCommodore InternationalMOS TechnologyMicro Instrumentation and Telemetry SystemsIMS Associates, Inc.Digital Equipment CorporationLincol'), 
    'IBM', false)

// Step 10: Take screenshot
WebUI.takeScreenshot()

// Step 11: Click create button
WebUI.click(findTestObject('Computers_database_OR/Create_Comp_btn'))

// Step 12: Verify if computer was created
boolean isCreated = WebUI.verifyTextPresent('Done ! Computer ASUS Strik has been created', false)

if (isCreated) {
    println('Done ! Computer ASUS Strik has been created')
} else {
    println('Not Done ! Computer ASUS Strik has been created')
}

