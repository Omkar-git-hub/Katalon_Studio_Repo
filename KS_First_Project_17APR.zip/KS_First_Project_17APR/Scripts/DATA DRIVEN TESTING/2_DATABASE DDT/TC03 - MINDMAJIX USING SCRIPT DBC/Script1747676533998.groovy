import java.sql.*
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

// Step 1: Load JDBC Driver
Class.forName("com.mysql.cj.jdbc.Driver")

// Step 2: DB connection details
String dbUrl = "jdbc:mysql://localhost:3306/katalon"
String username = "root"
String password = "root@123"  // Change if needed

// Step 3: Connect to DB
Connection conn = DriverManager.getConnection(dbUrl, username, password)
Statement stmt = conn.createStatement()
String query = "SELECT * FROM DB01"
ResultSet rs = stmt.executeQuery(query)

// Step 4: Loop through DB rows
while (rs.next()) {
    String name = rs.getString("Name") ?: "Test Name"
    String email = rs.getString("Email") ?: "test@example.com"
    String message = rs.getString("Message") ?: "No message"
    String phone = rs.getString("Phone") ?: "0000000000"
    String technology = rs.getString("Technology") ?: "General Testing"

    // Step 5: Open MindMajix site
    WebUI.openBrowser('')
    WebUI.navigateToUrl('https://mindmajix.com/')
    WebUI.maximizeWindow()

    // Step 6: Scroll and click Contact Us
    WebUI.scrollToElement(findTestObject('MINDMAJIX_OR/on job support clk'), 3)
    WebUI.click(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/Contact us clk'))

    // Step 7: Fill the form using DB values
    WebUI.setText(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/Name clk'), name)
    WebUI.setText(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/Email clk'), email)
    WebUI.setText(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/msg clk'), message)
    WebUI.setText(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/Phone clk'), phone)
    WebUI.setText(findTestObject('FORM SUBMISSION - MINDMAJIX_OR/Tech clk'), technology)

    // Step 8: Take screenshot
    String screenshotPath = WebUI.takeScreenshot()
    println("Screenshot saved at: " + screenshotPath)

    // Step 9: Close browser
    WebUI.closeBrowser()
}

// Step 10: Close DB connection
rs.close()
stmt.close()
conn.close()
