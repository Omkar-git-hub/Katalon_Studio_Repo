import java.sql.*
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

// Step 1: Load JDBC driver
Class.forName("com.mysql.cj.jdbc.Driver")

// Step 2: Set connection details
String dbUrl = "jdbc:mysql://localhost:3306/katalon"
String username = "root"
String password = "root@123"  // Replace with your actual password

// Step 3: Connect to DB
Connection conn = DriverManager.getConnection(dbUrl, username, password)

// Step 4: Create SQL query
String query = "SELECT * FROM DB01"

// Step 5: Execute query
Statement stmt = conn.createStatement()
ResultSet rs = stmt.executeQuery(query)

// Step 6: Loop through each row
while (rs.next()) {
    String name = rs.getString("Name")
    String email = rs.getString("Email")
    String course = rs.getString("Course")
    
    println("Name: " + name)
    println("Email: " + email)
    println("Course: " + course)
    
    // You can also use this data in WebUI steps
    // Example: WebUI.setText(findTestObject('ObjectName'), name)
}

// Step 7: Close connections
rs.close()
stmt.close()
conn.close()
