<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select State</name>
   <tag></tag>
   <elementGuidId>1d4fc71a-a160-49e3-aa47-54d1dc14c031</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;state&quot;)/div[@class=&quot;css-1pahdxg-control&quot;]/div[@class=&quot;css-1hwfws3&quot;]/div[@class=&quot;css-1wa3eu0-placeholder&quot;][count(. | //*[(text() = 'Select State' or . = 'Select State')]) = count(//*[(text() = 'Select State' or . = 'Select State')])]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(text(),'Select State')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.css-1pahdxg-control > div.css-1hwfws3 > div.css-1wa3eu0-placeholder</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4b17bb7b-9abf-4191-be1b-77cfc257309e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> css-1wa3eu0-placeholder</value>
      <webElementGuid>3ade49ab-9746-44fd-8192-94a805504f1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select State</value>
      <webElementGuid>75ae31c0-01df-4785-bd0f-c95986f2aa36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;state&quot;)/div[@class=&quot;css-1pahdxg-control&quot;]/div[@class=&quot;css-1hwfws3&quot;]/div[@class=&quot;css-1wa3eu0-placeholder&quot;]</value>
      <webElementGuid>aa37c017-bf4e-42b8-acdd-b48d2310f259</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='state']/div/div/div</value>
      <webElementGuid>03cbcbd7-8a2a-4a92-8248-b51628f74e19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State and City'])[1]/following::div[5]</value>
      <webElementGuid>3958bbb9-348b-4c47-bc31-584947394173</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Current Address'])[1]/following::div[8]</value>
      <webElementGuid>f3b0e917-ed99-4b64-ae61-ff8a2f60230e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NCR'])[1]/preceding::div[6]</value>
      <webElementGuid>b9accb9b-8e5b-49ff-851b-251f7700c475</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Uttar Pradesh'])[1]/preceding::div[7]</value>
      <webElementGuid>9f6d969f-3cb7-4baa-96f9-971b0dbbbf91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Select State']/parent::*</value>
      <webElementGuid>d77c6ab6-2ca5-4272-b9a8-980f9947c6ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div[2]/div/div/div/div</value>
      <webElementGuid>e8a20996-ab15-4191-8d86-7d2a49b84e11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select State' or . = 'Select State')]</value>
      <webElementGuid>b2dc9565-6dd3-4cd7-bd04-06442f4ccc84</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
