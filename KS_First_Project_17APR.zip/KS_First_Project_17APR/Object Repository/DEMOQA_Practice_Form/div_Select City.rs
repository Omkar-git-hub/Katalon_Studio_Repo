<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Select City</name>
   <tag></tag>
   <elementGuidId>13290363-df37-428d-8dfb-de77978b7bfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#city > div.css-yk16xz-control > div.css-1hwfws3</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[contains(text(),'Select City')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>fcea6372-7121-4ca0-a02f-3842a451e413</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> css-1hwfws3</value>
      <webElementGuid>89fb614e-a687-45c7-bdec-3ab32dcac9e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select City</value>
      <webElementGuid>f882118c-aaeb-4395-a5d6-6734e8299e5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;city&quot;)/div[@class=&quot;css-yk16xz-control&quot;]/div[@class=&quot;css-1hwfws3&quot;]</value>
      <webElementGuid>8a953b89-c41a-4a98-a7dd-fc97fd0596ec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='city']/div/div</value>
      <webElementGuid>57e723c7-d91c-45f1-9f1e-35fd20a97af1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Haryana'])[1]/following::div[9]</value>
      <webElementGuid>e73a3ac4-53d8-4dc5-a6a3-c67e605ee15b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='State and City'])[1]/following::div[14]</value>
      <webElementGuid>23acc60f-792a-4765-ae8e-693e1322efee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit'])[1]/preceding::div[7]</value>
      <webElementGuid>9ab19f0b-0538-4bb3-ac5c-2e2d79be209e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div</value>
      <webElementGuid>c7cc2ed0-2815-4d45-b273-785eac69b60a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Select City' or . = 'Select City')]</value>
      <webElementGuid>33accbe2-0369-4f2e-922b-362da88260fe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
