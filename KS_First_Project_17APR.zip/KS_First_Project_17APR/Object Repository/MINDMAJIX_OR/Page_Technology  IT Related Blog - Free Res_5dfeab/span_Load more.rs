<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Load more</name>
   <tag></tag>
   <elementGuidId>f993b038-3dea-4ab3-9b37-522f77ea7ec8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.redBtnInvert > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='MySQL Vs PostgreSQL Performance'])[1]/following::span[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9b1e6cc8-494f-4dae-894e-e935706658d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Load more</value>
      <webElementGuid>d04fa8c4-6d06-4a77-b870-989af7095d9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;styles_section__zjf8p&quot;]/div[@class=&quot;wraper styles_container__8FJHp&quot;]/div[@class=&quot;styles_btnSec__6qsTI&quot;]/button[@class=&quot;redBtnInvert&quot;]/span[1]</value>
      <webElementGuid>76c0851d-ea10-4552-bd18-fb03f23e9b18</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MySQL Vs PostgreSQL Performance'])[1]/following::span[4]</value>
      <webElementGuid>6a841852-5b3e-4dd4-a197-408b221270de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ServiceNow Scripting Interview Questions'])[1]/following::span[7]</value>
      <webElementGuid>f73c83ce-09f4-43ed-97ab-af5288a5ab87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='STILL GOT QUERIES?'])[1]/preceding::span[1]</value>
      <webElementGuid>a27a5532-5c1a-40e9-80c7-d50a3e8c01cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Load more']/parent::*</value>
      <webElementGuid>d19ee728-d3ae-41c2-9250-8e9f5936ef4f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>4356e89e-56e8-4188-9859-fd4a12d55890</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Load more' or . = 'Load more')]</value>
      <webElementGuid>989e22a0-72f0-4fcd-8ea3-6d0074202276</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
