<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Corporate Training</name>
   <tag></tag>
   <elementGuidId>f81eb54e-c524-43b2-993d-6d4ab6d6c58d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.style_topNavBar__sbFvf > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Corporate Training')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>39fefaec-1f9c-48ec-af96-6ad725cb5cbb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>f4722119-d2b0-4864-9bae-db55d9599868</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>rel</name>
      <type>Main</type>
      <value>noopener noreferrer</value>
      <webElementGuid>e18a9950-c9b7-4ce3-8db6-a56491f9c1e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/corporate-training</value>
      <webElementGuid>c3e92ea9-9fd3-4156-bcf5-f05878a0015a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Corporate Training</value>
      <webElementGuid>ec9133ae-4bd0-4b57-9639-3a304a084e16</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;style_headerWrap__5RQPy&quot;]/div[1]/div[@class=&quot;wraper&quot;]/nav[@class=&quot;style_topMiddleNav__ElFgL&quot;]/div[@class=&quot;style_right__ymqow&quot;]/ul[1]/li[@class=&quot;style_topNavBar__sbFvf&quot;]/a[1]</value>
      <webElementGuid>8f5bc49c-56ed-402f-9846-a8b23504f1c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Corporate Training')]</value>
      <webElementGuid>92238b2f-519f-47db-8064-825e86ad7fcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='On-Job Support'])[1]/preceding::a[1]</value>
      <webElementGuid>127b24a1-d199-4d31-86b0-8e2aa8b3cb50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Blog'])[1]/preceding::a[2]</value>
      <webElementGuid>d44660e9-a72c-46dc-b700-a2b3e674216a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Corporate Training']/parent::*</value>
      <webElementGuid>730ff22c-1c2a-4b23-9666-7150818b7939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/corporate-training')]</value>
      <webElementGuid>c24c0ace-aded-4134-9a03-1655dc272df6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>b1bd0eed-b4b9-4b30-881b-d367717d78c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/corporate-training' and (text() = 'Corporate Training' or . = 'Corporate Training')]</value>
      <webElementGuid>ed087472-fe2e-480c-b08b-ef05a6fa186d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
