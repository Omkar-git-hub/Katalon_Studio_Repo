<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>TS01 - CRUD CD</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>115e0990-defe-479d-ad50-7f82e3271389</testSuiteGuid>
   <testCaseLink>
      <guid>54cd5a54-32d2-409b-b963-e42cc285c7b2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KEYWORD - DRIVEN - TESTING/TCFA13 - CRUD_SEPERATE_CD/TC27 - CREATE COMPUTER</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>56f062d2-494f-49e3-b8df-77e3f31ddc0c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KEYWORD - DRIVEN - TESTING/TCFA13 - CRUD_SEPERATE_CD/TC28 - RENAME COMPUTER</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>29db0da5-f9d2-4f51-916b-a394e07f1e34</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KEYWORD - DRIVEN - TESTING/TCFA13 - CRUD_SEPERATE_CD/TC29 - UPDATE COMPUTER</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>ba6d90b9-36d9-4e2c-9cd2-f6e311e8f0ac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/KEYWORD - DRIVEN - TESTING/TCFA13 - CRUD_SEPERATE_CD/TC30 - DELETE COMPUTER</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
