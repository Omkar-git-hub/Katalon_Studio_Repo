package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object NAME
     
    /**
     * <p></p>
     */
    public static Object EMAIL
     
    /**
     * <p></p>
     */
    public static Object MSG
     
    /**
     * <p></p>
     */
    public static Object NUM
     
    /**
     * <p></p>
     */
    public static Object TECH
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            NAME = selectedVariables['NAME']
            EMAIL = selectedVariables['EMAIL']
            MSG = selectedVariables['MSG']
            NUM = selectedVariables['NUM']
            TECH = selectedVariables['TECH']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
